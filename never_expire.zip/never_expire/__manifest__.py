{
    "name": "Never Expire",
    "summary": """This Module set Database Never Expire""",
    "maintainer": "sayhi2awais@gmail.com",
    "category": "Tools",
    "author": "Muhammad Awais",
    "license": "LGPL-3",
    "version": "14.0.1.0.2",
    "website": "https://bit.ly/3E0SdcX",
    "depends": ["mail"],
    "data": ["views/update.xml"],
    "sequence": 999,
}
